# Archaeological Artifact Age and Material Prediction Using Machine Learning

This is a clean, small demonstration project using XGBoost classification to predict an artifact's **age period** and **material** from entered measurements.

## Important note
`data/sample_artifacts.csv` is an illustrative demonstration dataset created to let you test the app interface. It is **not** a verified archaeological dataset, and its predictions are not research findings. Replace it with your actual labeled dataset before reporting real accuracy or scientific conclusions.

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `archaeological_artifact_prediction` folder.
3. In that folder, click the address bar in File Explorer, type `cmd`, and press Enter.
4. Run these commands one by one:

```bat
py -m venv .venv
.venv\Scripts\activate
py -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

If `py` is not recognized, try using `python` instead of `py`.
The app should open in your browser. If it does not, copy the local URL printed in the command window (usually http://localhost:8501) into Chrome.

## CSV columns
`weight_g, length_cm, width_cm, thickness_cm, hardness, metal_content_pct, age_period, material`

The first six columns are numeric features. `age_period` and `material` are the known labels used for supervised training.

## Project workflow
1. Load CSV dataset.
2. Prepare numeric features and remove incomplete rows.
3. Train separate XGBoost classifiers for age period and material.
4. Enter measurements.
5. Display predicted age period and material.

## Troubleshooting
- Keep the Command Prompt open while using the app.
- If a package installation fails, check your internet connection and Python version (Python 3.10–3.12 is recommended).
- If port 8501 is already in use, run `streamlit run app.py --server.port 8502`.
