import streamlit as st
import pandas as pd
import numpy as np
from pathlib import Path

st.set_page_config(page_title="Archaeological Artifact Prediction", page_icon="🏺", layout="wide")

st.title("🏺 Archaeological Artifact Age and Material Prediction")
st.caption("Machine Learning Project | XGBoost")

st.info(
    "This project includes a small illustrative sample dataset for demonstration. "
    "Predictions are only as reliable as the labeled data used for training; "
    "do not treat the sample data as validated archaeological evidence."
)

DATA_PATH = Path(__file__).parent / "data" / "sample_artifacts.csv"

@st.cache_data
def load_sample():
    return pd.read_csv(DATA_PATH)

@st.cache_resource
def train_models(data):
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import LabelEncoder
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import Pipeline
    from sklearn.metrics import accuracy_score, mean_absolute_error
    from xgboost import XGBClassifier, XGBRegressor

    feature_cols = ["weight_g", "length_cm", "width_cm", "thickness_cm", "hardness", "metal_content_pct"]
    required = feature_cols + ["age_period", "material"]
    data = data.dropna(subset=["age_period", "material"]).copy()
    for col in feature_cols:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.dropna(subset=feature_cols)
    if len(data) < 8:
        raise ValueError("Please provide at least 8 complete labeled rows to train the models.")

    # Numeric age estimate from ordered period labels is not scientifically valid by itself.
    # Train the age-period classifier and material classifier as separate supervised models.
    age_encoder = LabelEncoder()
    age_y = age_encoder.fit_transform(data["age_period"].astype(str))
    material_encoder = LabelEncoder()
    material_y = material_encoder.fit_transform(data["material"].astype(str))
    X = data[feature_cols]

    age_model = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", XGBClassifier(n_estimators=80, max_depth=3, learning_rate=0.08,
                                objective="multi:softprob", eval_metric="mlogloss",
                                random_state=42))
    ])
    material_model = Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", XGBClassifier(n_estimators=80, max_depth=3, learning_rate=0.08,
                                objective="multi:softprob", eval_metric="mlogloss",
                                random_state=42))
    ])
    age_model.fit(X, age_y)
    material_model.fit(X, material_y)
    return feature_cols, age_model, material_model, age_encoder, material_encoder, len(data)

sample = load_sample()

with st.sidebar:
    st.header("Dataset")
    uploaded = st.file_uploader("Upload labeled artifact CSV (optional)", type=["csv"])
    st.caption("Required columns: weight_g, length_cm, width_cm, thickness_cm, hardness, metal_content_pct, age_period, material")

data = sample.copy()
if uploaded is not None:
    try:
        data = pd.read_csv(uploaded)
        st.success("Uploaded dataset loaded.")
    except Exception as exc:
        st.error(f"Could not read CSV: {exc}")
        data = sample.copy()

required_cols = ["weight_g", "length_cm", "width_cm", "thickness_cm", "hardness", "metal_content_pct", "age_period", "material"]
missing = [c for c in required_cols if c not in data.columns]
if missing:
    st.error("Dataset is missing required columns: " + ", ".join(missing))
    st.stop()

st.subheader("Dataset Preview")
st.dataframe(data.head(10), use_container_width=True)
st.caption(f"Rows available for training: {len(data)}")

try:
    feature_cols, age_model, material_model, age_encoder, material_encoder, nrows = train_models(data)
except Exception as exc:
    st.error(f"Model training failed: {exc}")
    st.stop()

st.subheader("Enter Artifact Measurements")
c1, c2, c3 = st.columns(3)
with c1:
    weight = st.number_input("Weight (g)", min_value=0.0, value=250.0, step=5.0)
    length = st.number_input("Length (cm)", min_value=0.0, value=12.0, step=0.5)
with c2:
    width = st.number_input("Width (cm)", min_value=0.0, value=6.0, step=0.5)
    thickness = st.number_input("Thickness (cm)", min_value=0.0, value=1.0, step=0.1)
with c3:
    hardness = st.number_input("Hardness (illustrative scale)", min_value=0.0, value=5.0, step=0.5)
    metal = st.number_input("Metal content (%)", min_value=0.0, max_value=100.0, value=2.0, step=0.5)

if st.button("Predict Artifact Age and Material", type="primary", use_container_width=True):
    row = pd.DataFrame([[weight, length, width, thickness, hardness, metal]], columns=feature_cols)
    age_idx = int(age_model.predict(row)[0])
    material_idx = int(material_model.predict(row)[0])
    age_label = age_encoder.inverse_transform([age_idx])[0]
    material_label = material_encoder.inverse_transform([material_idx])[0]
    a, b = st.columns(2)
    with a:
        st.success("Predicted Age Period")
        st.markdown(f"## {age_label}")
    with b:
        st.success("Predicted Material")
        st.markdown(f"## {material_label}")
    st.warning("Demonstration output only. Confirm predictions using a real, verified archaeological dataset and expert assessment.")

st.subheader("Project Workflow")
st.markdown("1. Load artifact dataset  →  2. Check and prepare features  →  3. Train XGBoost classification models  →  4. Enter artifact measurements  →  5. Predict age period and material")
